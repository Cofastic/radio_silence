Radio Silence - Misc - deploy notes
===================================

Single container, no docker-compose. BIND9 serving a DNSSEC-signed zone (plain NSEC).
Zone files are pre-generated and baked into the image; signing keys are created
automatically at first start.

Build:
    docker build -t radio-silence .

Run (players connect to host port 5052; DNS needs BOTH UDP and TCP):
    docker run -d --name radio-silence --restart unless-stopped \
        -p 5052:53/udp -p 5052:53/tcp radio-silence

Use any host port you like, e.g. -p 5000:53/udp -p 5000:53/tcp.
The container listens on port 53 internally.

Quick checks (from another machine; replace HOST and PORT):
    dig @HOST -p PORT comms-check.cofastic.com TXT +short
        -> "radio_check_Over_And_Out"
    dig @HOST -p PORT relay-000.signals.cofastic.com NSEC +short
        -> relay-001.signals.cofastic.com. AAAA SRV RRSIG NSEC
    dig @HOST -p PORT signals.cofastic.com AXFR +tcp
        -> Transfer failed (zone transfers are refused on purpose)

Notes for organizers
- Open BOTH UDP and TCP on the published port in your firewall.
- Stateless: restarting the container is safe. The zone content (and therefore the flag)
  never changes between restarts or rebuilds; only the DNSSEC keys are regenerated,
  which does not affect the challenge.
- Challenge text should give: <server>:<port> (UDP/TCP) and zone name signals.cofastic.com.
  The zone name is an arbitrary label; no real DNS delegation is needed.
- Resource use is tiny (well under 100 MB RAM, negligible CPU).
- No privileged mode or extra capabilities are needed.
